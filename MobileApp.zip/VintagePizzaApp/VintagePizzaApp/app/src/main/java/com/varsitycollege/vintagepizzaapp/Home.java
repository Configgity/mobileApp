package com.varsitycollege.vintagepizzaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {
 private Button btnStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnStatus = (Button) findViewById(R.id.btn_status);

        btnStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openSetStatus();
            }
        });
    }
    public void openSetStatus(){
        Intent intent = new Intent(this, SetStatus.class);
        startActivity(intent);
    }
}