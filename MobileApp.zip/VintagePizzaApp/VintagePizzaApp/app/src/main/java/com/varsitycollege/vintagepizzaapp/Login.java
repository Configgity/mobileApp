package com.varsitycollege.vintagepizzaapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Login extends AppCompatActivity {

    Button login1;
    Connection conn;
    EditText userName,passWord;
    Context context1;

    Statement stat;
    String ipaddress, db, user, pass;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login1 = (Button) findViewById(R.id.login);
        userName = (EditText) findViewById(R.id.txt_username);
        passWord = (EditText) findViewById(R.id.txt_password);

        ipaddress = "172.18.208.1";
        db="CROWN";
        user="sa";
        pass="123";

       login1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               try{

                   String sql="select AdminUsername,AdminPassword from Admin where AdminUsername="+ userName.getText().toString()+ ",AdminPassword="+ passWord.getText().toString();
                   stat = conn.createStatement();
                   ResultSet rs = stat.executeQuery(sql);
               }
           }
       });
        conn = ConnectionHelper(user, pass,db,ipaddress);
    }
    @SuppressLint("NewApi")
    private Connection ConnectionHelper(String username, String password, String database, String server){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        Connection connection = null;
        String ConnectionUrl = null;
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionUrl ="jdbc:jtds:sqlserver://"+ server + ";"+"databaseName="+ database+";user="+ username +";password="+password+";";
            connection = DriverManager.getConnection(ConnectionUrl);
        }catch(SQLException se){
            Log.e("ERRO",se.getMessage());
        }catch(ClassNotFoundException e){
            Log.e("ERRO",e.getMessage());
        }catch(Exception ex){
            Log.e("ERRO",ex.getMessage());
        }
        return connection;
    }



}